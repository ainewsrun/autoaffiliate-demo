import os, json, re, datetime, markdown
from jinja2 import Environment, FileSystemLoader, select_autoescape

ROOT = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(ROOT)

def getenv_default(name, default):
    return os.environ.get(name, default)

def load_json(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def ensure_dir(path):
    os.makedirs(path, exist_ok=True)

def build_meta(site, lang, slug_parts, title, description):
    base_url = getenv_default('SITE_BASE_URL', 'https://example.com')
    path = '/' + '/'.join(slug_parts)
    canonical = base_url.rstrip('/') + path
    og_image = site.get('og_default_image', '/assets/og-default.png')
    return {
        "title": title,
        "description": description,
        "canonical": canonical,
        "og_title": title,
        "og_description": description,
        "og_image": og_image
    }

def has_gate(affiliates, gate_keys):
    for k in gate_keys:
        url = affiliates.get(k, '').strip()
        if url:
            return True
    return False

def pick_cta(affiliates, gate_keys):
    for k in gate_keys:
        if affiliates.get(k, '').strip():
            return affiliates[k].strip()
    return None

def render(env, tpl, outpath, **ctx):
    ensure_dir(os.path.dirname(outpath))
    html = env.get_template(tpl).render(**ctx)
    with open(outpath, 'w', encoding='utf-8') as f:
        f.write(html)

def to_html(md_text):
    return markdown.markdown(md_text, extensions=['extra', 'tables'])

def load_md_posts(content_dir):
    posts = []
    if not os.path.isdir(content_dir):
        return posts
    for name in os.listdir(content_dir):
        if name.endswith('.md'):
            path = os.path.join(content_dir, name)
            with open(path, 'r', encoding='utf-8') as f:
                raw = f.read()
            # very simple front-matter: first line = title, second = date (YYYY-MM-DD)
            lines = raw.strip().splitlines()
            if len(lines) >= 2:
                title = lines[0].lstrip('# ').strip()
                date = lines[1].strip()
                body = '\n'.join(lines[2:]).strip()
            else:
                title = name[:-3]
                date = datetime.date.today().isoformat()
                body = raw
            posts.append({
                "title": title,
                "date": date,
                "body": body,
                "path": path
            })
    posts.sort(key=lambda x: x['date'], reverse=True)
    return posts

def main():
    site = load_json(os.path.join(REPO, 'config', 'site.json'))
    affiliates = load_json(os.path.join(REPO, 'config', 'affiliates.json'))
    gates = load_json(os.path.join(REPO, 'config', 'gates.json'))
    usecases = load_json(os.path.join(REPO, 'config', 'usecases.json'))
    languages = load_json(os.path.join(REPO, 'config', 'languages.json'))
    countries = load_json(os.path.join(REPO, 'config', 'countries.json'))

    env = Environment(
        loader=FileSystemLoader(os.path.join(REPO, 'templates')),
        autoescape=select_autoescape(['html'])
    )

    # Build /docs root pages per default language only
    docs = os.path.join(REPO, 'docs')
    ensure_dir(docs)

    # Menu builds only for gates that pass
    menu = []
    tiles = []
    def maybe_add(section_key, text, href):
        gate_keys = gates.get(section_key, [])
        if has_gate(affiliates, gate_keys):
            menu.append({"text": text, "href": href})
            tiles.append({"title": text, "desc": f"Explore {text}", "href": href})

    maybe_add('vpn', 'VPN', '/vpn/index.html')
    maybe_add('how_to_watch', 'How to watch', '/how-to-watch/index.html')
    maybe_add('hosting', 'Hosting', '/hosting/index.html')
    maybe_add('saas_deals', 'SaaS Deals', '/saas-deals/index.html')
    maybe_add('weekly_payouts', 'Weekly payouts', '/weekly-payouts/index.html')
    # Blog is always present
    menu.append({"text":"Blog", "href":"/blog/index.html"})
    tiles.append({"title":"Blog", "desc":"Latest posts and updates", "href":"/blog/index.html"})

    # Index
    meta = build_meta(site, site.get('default_lang','en'), ['index.html'], f"{site.get('site_name')} – Home", "Programmatic affiliate engine")
    render(env, 'index.html', os.path.join(docs, 'index.html'),
           site=site, lang=site.get('default_lang','en'), meta=meta, menu=menu, tiles=tiles)

    # Category pages (country/language aware only when gated)
    def build_category(section_key, title, intro, cta_label):
        if not has_gate(affiliates, gates.get(section_key, [])):
            return
        base_dir = os.path.join(docs, section_key.replace('_','-'))
        ensure_dir(base_dir)
        cta_url = pick_cta(affiliates, gates.get(section_key, []))
        # Generate per language x country pages
        for lang in languages:
            lang_code = lang['code']
            lang_dir = os.path.join(base_dir, lang_code)
            ensure_dir(lang_dir)
            # index per language
            lang_meta = build_meta(site, lang_code, [section_key.replace('_','-'), lang_code, 'index.html'],
                                   f"{title} – {lang_code.upper()}", intro)
            render(env, 'landing.html', os.path.join(lang_dir, 'index.html'),
                   site=site, lang=lang_code, meta=lang_meta, menu=menu,
                   h1=f"{title} ({lang_code.upper()})", intro=intro,
                   cta_url=cta_url, cta_label=cta_label,
                   items=[{"title":"Getting Started","desc":"Quick intro"}])

            # per country page
            for c in countries:
                slug = re.sub(r'[^a-z0-9-]+','-', c['slug']).strip('-')
                country_meta = build_meta(site, lang_code, [section_key.replace('_','-'), lang_code, f"{slug}.html"],
                                          f"{title} – {c['name']} ({lang_code.upper()})",
                                          f"{intro} – {c['name']}")
                render(env, 'landing.html', os.path.join(lang_dir, f"{slug}.html"),
                       site=site, lang=lang_code, meta=country_meta, menu=menu,
                       h1=f"{title} in {c['name']}",
                       intro=f"{intro} – {c['name']}", cta_url=cta_url, cta_label=cta_label,
                       items=[{"title":f"Best option for {c['name']}","desc":"Top pick based on value/performance"}])

    build_category('vpn', 'Best VPN', 'Our value picks by country', 'Get VPN')
    build_category('how_to_watch', 'How to watch', 'Unlock streaming libraries with VPN', 'Open guide')
    build_category('hosting', 'Best Hosting', 'Reliable hosting providers for any project', 'Get Hosting')
    build_category('saas_deals', 'SaaS Deals', 'Curated discounts & lifetime deals', 'Browse deals')
    build_category('weekly_payouts', 'Weekly/Instant Payouts', 'Affiliate networks with fast payouts', 'Join network')

    # Blog
    blog_dir = os.path.join(docs, 'blog')
    ensure_dir(blog_dir)
    posts_all = []
    for lang in languages:
        lang_code = lang['code']
        content_dir = os.path.join(REPO, 'content', 'blog', lang_code)
        posts = load_md_posts(content_dir)
        # write posts
        for p in posts:
            html = to_html(p['body'])
            out = os.path.join(blog_dir, f"{lang_code}-{os.path.basename(p['path']).replace('.md','.html')}")
            meta = build_meta(site, lang_code, ['blog', os.path.basename(out)],
                              p['title'], p['title'])
            render(env, 'blog_post.html', out,
                   site=site, lang=lang_code, meta=meta, menu=menu,
                   post={"title":p['title'], "date":p['date'], "html":html, "lang":lang_code})
            posts_all.append({"title":p['title'], "date":p['date'], "href":"/blog/"+os.path.basename(out)})
    # blog index
    meta = build_meta(site, site.get('default_lang','en'), ['blog','index.html'], "Blog", "Updates and articles")
    render(env, 'blog_index.html', os.path.join(blog_dir, 'index.html'),
           site=site, lang=site.get('default_lang','en'), meta=meta, menu=menu, posts=posts_all)

    # Disclosure page
    disclosure_html = "<h1>Affiliate Disclosure</h1><p>This website contains affiliate links. If you click and buy, we may earn a commission at no extra cost to you.</p>"
    with open(os.path.join(docs, 'disclosure.html'), 'w', encoding='utf-8') as f:
        f.write(f"<!doctype html><meta charset='utf-8'><title>Disclosure</title>{disclosure_html}")

    # Simple robots.txt & sitemap (sitemap minimal; GH Pages can serve it)
    with open(os.path.join(docs, 'robots.txt'), 'w', encoding='utf-8') as f:
        f.write("User-agent: *\nAllow: /\nSitemap: /sitemap.xml\n")

    # Naive sitemap from docs walk
    urls = []
    base_url = os.environ.get('SITE_BASE_URL', 'https://example.com').rstrip('/')
    for dirpath, _, filenames in os.walk(docs):
        for fn in filenames:
            if fn.endswith('.html'):
                rel = os.path.relpath(os.path.join(dirpath, fn), docs).replace('\\','/')
                urls.append(base_url + '/' + rel)
    with open(os.path.join(docs, 'sitemap.xml'), 'w', encoding='utf-8') as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n')
        f.write('<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n')
        for u in urls:
            f.write(f'  <url><loc>{u}</loc></url>\n')
        f.write('</urlset>\n')

    print("Build complete. Files written to /docs")

if __name__ == "__main__":
    main()