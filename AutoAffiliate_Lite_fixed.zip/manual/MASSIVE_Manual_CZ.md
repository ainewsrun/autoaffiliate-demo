# MASSIVE_Manual_CZ

Tento manuál popisuje nasazení a rozšíření projektu:
- **GitHub Pages**: hostuje statický web ze složky `/docs`
- **GitHub Actions**: každých 6 hodin spustí build (cron) a přegeneruje stránky
- **Gating**: sekce vznikají pouze tam, kde je vyplněný affiliate odkaz

## Kroky
1. Nahraj repozitář na GitHub.
2. Nastav Pages na branch `main` a složku `/docs`.
3. (Volitelně) Přidej secret `SITE_BASE_URL`.
4. Doplň affiliate odkazy v `config/affiliates.json`.
5. Spusť build v **Actions** ručně (poprvé), poté pojede sám dle cronu.