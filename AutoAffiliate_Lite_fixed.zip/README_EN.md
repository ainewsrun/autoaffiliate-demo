# AutoAffiliate (Lite)

**Autonomous programmatic affiliate site** – static output on **GitHub Pages**,
built via **GitHub Actions** (Python + Jinja2). Cost: $0/month.

## Quick start (for complete beginners)
1. Sign in to GitHub → click **New repository** → name it (e.g., `autoaffiliate`).
2. Upload **all files** from this bundle to the repo (drag & drop on GitHub → **Commit**).
3. Go to **Settings → Pages**:
   - Source: **Deploy from a branch**
   - Branch: **main** and folder: **/docs**
   - Save (GitHub Pages will create a URL).
4. (Optional) **Settings → Secrets and variables → Actions → New repository secret**:
   - Name: `SITE_BASE_URL`
   - Value: your domain, e.g., `https://yourdomain.com`
5. Go to **Actions → Build & Deploy (cron)** and click **Run workflow** (to run the first build).
6. Open **`config/affiliates.json`** and paste your affiliate links (at least one – e.g., `nordvpn_url`).
   - Then **Run workflow** again. Gating ensures only relevant sections are generated.