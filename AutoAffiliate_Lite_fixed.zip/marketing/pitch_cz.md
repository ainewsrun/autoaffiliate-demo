# Prodejní pitch (CZ)

**AutoAffiliate – autonomní programatický affiliate web**  
15 jazyků · ~170 zemí · 5+ use-case · nulové fixní náklady (GitHub Pages)

## Proč to funguje
- Programatické SEO pokrývá long-tail ve více jazycích a zemích.
- Build přes GitHub Actions – bez serveru, bez správy.
- Striktní „gating“ – stránky vznikají jen tam, kde máš vyplněné affiliate odkazy.

## Co kupující získá
- Kompletní repozitář připravený k nasazení (šablony, generátor, workflow).
- SEO meta (title, description, canonical, OG) out-of-the-box.
- Blog/authority vrstva + disclosure (compliance).
- Cron build každých 6 h (lze změnit).

## Cena & licence
- Doporučená cena: **$99–199** za licenci (Lite → nižší, Massive → vyšší).