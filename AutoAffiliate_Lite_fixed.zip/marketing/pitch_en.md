# Sales Pitch (EN)

**AutoAffiliate – autonomous programmatic affiliate site**  
15 languages · ~170 countries · 5+ use-cases · zero fixed costs (GitHub Pages)

## Why it works
- Programmatic SEO covers long-tail across multiple locales.
- Built via GitHub Actions – no servers, no ops.
- Strict gating – only generates pages where affiliate links are configured.

## What buyers get
- Full GitHub-ready repo (templates, generator, workflow).
- SEO meta (title, description, canonical, OG) out of the box.
- Blog/authority layer + disclosure (compliance).
- Cron build every 6h (configurable).

## Price & license
- Suggested price: **$99–199** per license (Lite → lower, Massive → higher).