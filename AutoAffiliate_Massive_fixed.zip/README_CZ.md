# AutoAffiliate (Massive)

**Autonomní programatický affiliate web** – statický výstup hostovaný na **GitHub Pages**,
generovaný přes **GitHub Actions** (Python + Jinja2). Náklady: 0 Kč/měsíc.

## Jak spustit (pro úplné začátečníky)
1. Přihlas se na GitHub → klikni **New repository** → zadej název (např. `autoaffiliate`).
2. Ve svém počítači rozbal tento balík a nahraj **celý obsah** do repozitáře (přetáhni složky a soubory do GitHubu → **Commit**).
3. V repu klikni **Settings → Pages**:
   - Source: **Deploy from a branch**
   - Branch: **main** a složka: **/docs**
   - Ulož (GitHub Pages vygeneruje URL).
4. (Volitelné) **Settings → Secrets and variables → Actions → New repository secret**:
   - Name: `SITE_BASE_URL`
   - Value: tvá doména, např. `https://mojedomena.cz`
5. Přejdi na **Actions → Build & Deploy (cron)** a klikni **Run workflow** (ručně spustit první build).
6. Otevři **config/affiliates.json** a doplň své affiliate odkazy (alespoň jeden – např. `nordvpn_url`).
   - Pak znovu **Run workflow**. Gating zajistí, že se vygenerují jen sekce, kde je vyplněný odkaz.

## Kde vyplnit odkazy
- Soubor **`config/affiliates.json`** – sem vlož odkaz pro:
  - `nordvpn_url` → VPN/How to watch
  - `hostinger_url` → Hosting
  - `appsumo_url` → SaaS/AppSumo
  - `jvzoo_url`, `maxbounty_url`, `mobidea_url`, `cpagrip_url` → Weekly/Instant payouts (CPA)
- Pokud zůstane prázdné, sekce se **nevytváří** (gating).

## Doporučení pro SEO & compliance
- V `templates/partials/disclosure.html` je **affiliate disclosure** (zůstane na všech stránkách).
- Ideálně přidej 1–2 **blog posty měsíčně** do `content/blog/<jazyk>/`.
- Obrázky používej **vlastní** nebo z **free stock** (Unsplash, Pexels).

---
**Poznámka:** Výstup webu je ve složce **`docs/`** (automaticky vytvoří build skript).